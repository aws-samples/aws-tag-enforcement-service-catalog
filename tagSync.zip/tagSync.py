import json
import boto3
import os
import logging
from collections import defaultdict

logger = logging.getLogger()
logger.setLevel(logging.INFO)

sc=boto3.client('servicecatalog')
dydb=boto3.resource('dynamodb')
tbl=dydb.Table('SCTagOptions')

def get_sc_tags():
    tagsOnSc = defaultdict(list)
    try:
        for tag in sc.list_tag_options()['TagOptionDetails']:
            if tag['Active']:
                tagsOnSc[tag['Key']].append(tag['Value'])
        return(tagsOnSc)
    except Exception as e1:
        print("Exception occurred: "+str(e1))


def update_sc_tagoptions(newTags, action):
    ''' Add / Remove new tags in Service Catalog'''
    scDict = get_sc_tags()
    if action == 'INSERT' or action == 'MODIFY':
        for Key in newTags.keys():
            if Key not in scDict.keys():
                logger.info('Adding new tags : {}'.format(newTags))
                add_new_tags(newTags,action)
            else:
                if all(e in scDict[Key] for e in newTags[Key]):
                    logger.info('Tag combination {} exists.. skipping'.format(newTags[Key]))
                else:
                    logger.info('Adding New Tags : {}'.format(newTags))
                    add_new_tags(newTags,action)

    elif action == 'REMOVE':
        for Key in newTags.keys():
            if Key in scDict.keys():
                if all(e in scDict[Key] for e in newTags[Key]):
                    logger.info('Removing New Tags : {}'.format(newTags))
                    delete_new_tags(newTags)


def get_tag_id(newTags):
    try:
        currTagOptionsList=sc.list_tag_options()['TagOptionDetails']
    except Exception as e2:
        print("Exception occurred: "+str(e2))
    for Key in newTags.keys():
        for item in currTagOptionsList:
            if Key == item['Key'] and newTags[Key][0] == item['Value']:
                return(item['Id'])


def create_tag_option(newTags):
    for Key in newTags.keys():
        logger.info('Creating Tag Option : {}.{}'.format(Key, newTags[Key][0]))
        try:
            sc.create_tag_option(Key=Key, Value=newTags[Key][0])
        except Exception as e3:
            print("Exception occurred: "+str(e3))
        tagOptId = get_tag_id(newTags)
        logger.info('TagOptionId {}'.format(tagOptId))
        associate_tags(tagOptId)


def add_new_tags(newTags,action):
    resourceList = list_of_portfolios()
    if action == 'INSERT':
        create_tag_option(newTags)
    else:
        for Key in newTags.keys():
            logger.info('Updating Tag Option : {}.{}'.format(Key, newTags[Key][0]))
            try:
                sc.update_tag_option(Key=Key, Value=newTags[Key][0])
            except Exception as e3:
                print("Exception occurred: "+str(e3))



def delete_new_tags(newTags):
    tagOptId=get_tag_id(newTags)
    resourceList = list_associates_for_tag(tagOptId)
    disassociate_tags(resourceList, tagOptId)
    logger.info('Deleting Tag Option : {}'.format(tagOptId))
    try:
        sc.delete_tag_option(Id=tagOptId)
    except Exception as e4:
        print("Exception occurred: "+str(e4))


def list_associates_for_tag(tagOptId):
    resourceList=[]
    try:
        for item in sc.list_resources_for_tag_option(TagOptionId=tagOptId)['ResourceDetails']:
            resourceList.append(item['Id'])
        return(resourceList)
    except Exception as e5:
        print("Exception occurred: "+str(e5))

def disassociate_tags(resourceList, tagOptId):
    for item in resourceList:
        logger.info('Disassociating {} from {}'.format(tagOptId, item))
        try:
            sc.disassociate_tag_option_from_resource(ResourceId=item, TagOptionId=tagOptId)
        except Exception as e6:
            print("Exception occurred: "+str(e6))


def associate_tags(tagOptId):
    resourceList = list_of_portfolios()
    logger.info('ResourceList : {}'.format(resourceList))
    for item in resourceList:
        logger.info('Associating {} from {}'.format(tagOptId, item))
        try:
            sc.associate_tag_option_with_resource(ResourceId=item, TagOptionId=tagOptId)
        except Exception as e7:
            print("Exception occurred: "+str(e7))


def list_of_portfolios():
    portList=[]
    try:
        for item in sc.list_portfolios()['PortfolioDetails']:
            portList.append(item['Id'])
        return(portList)
    except Exception as e8:
        print("Exception occurred: "+str(e8))


def lambda_handler(event, context):
    tagsOnSc = defaultdict(list)
    tagsOnDyno = defaultdict(list)
    newTags = dict()
    
    for record in event['Records']:
        Key = record['dynamodb']['Keys']['Key']['S']
        Value = record['dynamodb']['Keys']['Value']['S']
        action = record['eventName']
        newTags[Key] = [Value]
        logger.info('Changing : {}'.format(newTags))
        update_sc_tagoptions(newTags, action)

    return(event)

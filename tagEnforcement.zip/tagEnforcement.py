
####
 # Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 #
 # Permission is hereby granted, free of charge, to any person obtaining a copy of this
 # software and associated documentation files (the "Software"), to deal in the Software
 # without restriction, including without limitation the rights to use, copy, modify,
 # merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 # permit persons to whom the Software is furnished to do so.
 #
 # THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 # INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 # PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 # HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 # OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 # SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 ####
import json
import boto3
import sys

def lambda_handler(event, context):
    print(event)
    sc = boto3.client('servicecatalog')
    portfolioId = event['detail']['responseElements']['portfolioDetail']['id']
    region = event['region']

    #Get TagOptions
    try:
        tag_options = (sc.list_tag_options(Filters={'Active':True}))['TagOptionDetails']
    except Exception as e1:
        print("Exception occurred: "+str(e1))
        tag_options = "Error"

    #Associate tag options
    if tag_options is not "Error":
        for i in tag_options:
            print("Associating tagOption " + i['Key'] + "=" + i['Value'] + " to AWS Service Catalog portfolio id="+portfolioId + " in "+region )
            try:
                response = sc.associate_tag_option_with_resource(ResourceId=portfolioId,TagOptionId=i['Id'])
                print("HTTP Status Code="+str(response['ResponseMetadata']['HTTPStatusCode']))
            except Exception as e2:
                print("Exception occurred: "+str(e2))
                return {
                    'statusCode': 404,
                    'body': json.dumps('TagOptions could not be applied successfully'),
                    'message':portfolioId
                }
    else:
        print("Cannot list TagOptions for your AWS Service Catalog in region "+region)
        return {
            'statusCode': 404,
            'body': json.dumps('TagOptions could not be applied successfully'),
            'message':portfolioId
        }

    return {
        'statusCode': 200,
        'body': json.dumps('TagOptions applied successfully'),
        'message':portfolioId
    }

import json
import boto3
import sys

def lambda_handler(event, context):
    print(event)
    sc = boto3.client('servicecatalog')
    portfolioId = event['detail']['responseElements']['portfolioDetail']['id']
    region = event['region']

    #Get TagOptions
    try:
        tag_options = (sc.list_tag_options(Filters={'Active':True}))['TagOptionDetails']
    except Exception as e1:
        print("Exception occurred: "+str(e1))
        tag_options = "Error"

    #Associate tag options
    if tag_options is not "Error":
        for i in tag_options:
            print("Associating tagOption " + i['Key'] + "=" + i['Value'] + " to AWS Service Catalog portfolio id="+portfolioId + " in "+region )
            try:
                response = sc.associate_tag_option_with_resource(ResourceId=portfolioId,TagOptionId=i['Id'])
                print("HTTP Status Code="+str(response['ResponseMetadata']['HTTPStatusCode']))
            except Exception as e2:
                print("Exception occurred: "+str(e2))
                return {
                    'statusCode': 404,
                    'body': json.dumps('TagOptions could not be applied successfully'),
                    'message':portfolioId
                }
    else:
        print("Cannot list TagOptions for your AWS Service Catalog in region "+region)
        return {
            'statusCode': 404,
            'body': json.dumps('TagOptions could not be applied successfully'),
            'message':portfolioId
        }

    return {
        'statusCode': 200,
        'body': json.dumps('TagOptions applied successfully'),
        'message':portfolioId
    }
